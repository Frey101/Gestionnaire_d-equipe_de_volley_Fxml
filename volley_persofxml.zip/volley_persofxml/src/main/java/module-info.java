module com.example.volley_persofxml {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;

    opens com.example.volley_persofxml to javafx.fxml;
    exports com.example.volley_persofxml;
}